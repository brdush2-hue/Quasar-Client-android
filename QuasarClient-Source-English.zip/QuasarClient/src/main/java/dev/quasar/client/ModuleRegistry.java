package dev.quasar.client;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Central registry for Quasar's client modules.
 */
public final class ModuleRegistry {
    private static final Map<String, ClientModule> MODULES = new LinkedHashMap<>();
    private static boolean defaultsRegistered;

    private ModuleRegistry() {}

    public static void registerDefaults() {
        if (defaultsRegistered) {
            return;
        }
        register(new ClientModule("hud", "HUD"));
        register(new ClientModule("interface", "Interface"));
        register(new ClientModule("visuals", "Visuals"));
        register(new ClientModule("performance", "Performance"));
        defaultsRegistered = true;
    }

    public static void register(ClientModule module) {
        if (MODULES.putIfAbsent(module.id(), module) != null) {
            throw new IllegalArgumentException("Duplicate Quasar module id: " + module.id());
        }
    }

    public static ClientModule get(String id) {
        return MODULES.get(id);
    }

    public static Collection<ClientModule> all() {
        return Collections.unmodifiableCollection(MODULES.values());
    }
}

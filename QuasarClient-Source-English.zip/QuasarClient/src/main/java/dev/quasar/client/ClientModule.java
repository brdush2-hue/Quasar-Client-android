package dev.quasar.client;

/**
 * Small foundation for independently toggleable client modules.
 * Modules are intentionally passive until implemented and tested.
 */
public final class ClientModule {
    private final String id;
    private final String displayName;
    private boolean enabled;

    public ClientModule(String id, String displayName) {
        this.id = id;
        this.displayName = displayName;
        this.enabled = false;
    }

    public String id() {
        return id;
    }

    public String displayName() {
        return displayName;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}

package dev.quasar.client;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Main client entrypoint. Keep client-only code in this package.
 */
public final class QuasarClient implements ClientModInitializer {
    public static final String MOD_ID = "quasar";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        ModuleRegistry.registerDefaults();
        LOGGER.info("Quasar Client initialized. Registered {} modules.", ModuleRegistry.all().size());
    }
}

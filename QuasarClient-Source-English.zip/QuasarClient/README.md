# Quasar Client

Initial Fabric client-mod scaffold for Minecraft Java 1.21.11.

## Requirements
- Java 21
- Gradle (or generate a Gradle wrapper in Codespaces)

## Build in GitHub Codespaces
From the project root, run:

```bash
gradle wrapper --gradle-version 9.2.1
./gradlew build
```

The resulting mod JAR should appear under `build/libs/`.

## Current scope
- Fabric mod metadata and client entrypoint
- A minimal client-side module registry foundation
- No gameplay-changing modules enabled by default yet

This is an initial scaffold, not a finished client. Test in a separate Minecraft instance and keep backups of worlds.
